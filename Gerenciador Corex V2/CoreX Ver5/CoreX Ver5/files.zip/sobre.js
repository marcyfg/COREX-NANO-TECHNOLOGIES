/* ===========================
   COREX NANO TECHNOLOGIES
   sobre.js — Scripts da página Sobre Nós
=========================== */

// ========================
// NAVBAR — scroll + hamburger
// ========================
const navbar    = document.getElementById('navbar');
const backTop   = document.getElementById('backToTop');
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');

window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 60);
  backTop.classList.toggle('visible', window.scrollY > 300);
}, { passive: true });

backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('active');
  navLinks.classList.toggle('open');
});

navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navLinks.classList.remove('open');
  });
});

// ========================
// CARROSSEL
// ========================
const track    = document.getElementById('carouselTrack');
const slides   = track.querySelectorAll('.carousel-slide');
const dots     = document.querySelectorAll('.dot');
const progress = document.getElementById('carouselProgress');
const prevBtn  = document.getElementById('prevBtn');
const nextBtn  = document.getElementById('nextBtn');

let current  = 0;
let interval;
const DURATION = 5000; // milissegundos por slide — altere aqui se quiser mudar a velocidade

function goTo(index) {
  slides[current].classList.remove('active');
  dots[current].classList.remove('active');
  current = (index + slides.length) % slides.length;
  slides[current].classList.add('active');
  dots[current].classList.add('active');
  track.style.transform = `translateX(-${current * 100}%)`;
  restartProgress();
}

function restartProgress() {
  progress.style.transition = 'none';
  progress.style.width = '0%';
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      progress.style.transition = `width ${DURATION}ms linear`;
      progress.style.width = '100%';
    });
  });
}

function startAuto() {
  clearInterval(interval);
  interval = setInterval(() => goTo(current + 1), DURATION);
}

prevBtn.addEventListener('click', () => { goTo(current - 1); startAuto(); });
nextBtn.addEventListener('click', () => { goTo(current + 1); startAuto(); });

dots.forEach(dot => {
  dot.addEventListener('click', () => {
    goTo(+dot.dataset.index);
    startAuto();
  });
});

// Suporte a swipe (mobile)
let touchStartX = 0;
track.addEventListener('touchstart', e => {
  touchStartX = e.touches[0].clientX;
}, { passive: true });
track.addEventListener('touchend', e => {
  const diff = touchStartX - e.changedTouches[0].clientX;
  if (Math.abs(diff) > 50) {
    goTo(current + (diff > 0 ? 1 : -1));
    startAuto();
  }
}, { passive: true });

// Inicializa
goTo(0);
startAuto();

// ========================
// SCROLL REVEAL
// ========================
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.fade-in').forEach((el, i) => {
  el.style.transitionDelay = `${(i % 4) * 70}ms`;
  observer.observe(el);
});
