@echo off
cd /d "%~dp0corex_desktop"
py -m venv .venv
call .venv\Scripts\activate.bat
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
if errorlevel 1 (
 echo.
 echo Houve erro na instalacao. Recomenda-se Python 3.12 ou 3.13.
 pause
 exit /b 1
)
echo.
echo Instalacao concluida.
pause
