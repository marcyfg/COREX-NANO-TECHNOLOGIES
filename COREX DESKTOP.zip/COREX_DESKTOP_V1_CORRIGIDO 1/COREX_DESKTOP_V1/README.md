# COREX Desktop V1

Aplicativo PySide6 criado para utilizar a mesma base da VER42 publicada no PythonAnywhere.

## Instalação
1. Instale preferencialmente Python 3.12 ou 3.13.
2. Execute `INSTALAR_COREX.bat`.
3. Aplique o patch da pasta `PATCH_PYTHONANYWHERE_VER42` no projeto online.
4. Execute `ABRIR_COREX.vbs` para abrir sem janela de CMD. O `.bat` continua disponível como alternativa.

O aplicativo já aponta para `https://corextech.pythonanywhere.com`.

## Recursos desta V1
- Login
- Dashboard
- Novo chamado
- Listagem e pesquisa
- Detalhes, comentários e tratamento
- Notificações
- Cadastro e gerenciamento de usuários para perfis autorizados

## Segurança
O banco online não está incluído nem é substituído. O site VER42 continua funcionando durante a validação do desktop.


## Correção V1.1
- Corrige o pacote do servidor para as rotas de Notificações e Usuários.
- Adiciona `/api/desktop/status` para confirmar que o patch completo está publicado.
- Aceita PUT, POST e PATCH ao marcar notificações.
- Inclui inicializador `ABRIR_COREX.vbs`, que abre o aplicativo com o CMD oculto.
