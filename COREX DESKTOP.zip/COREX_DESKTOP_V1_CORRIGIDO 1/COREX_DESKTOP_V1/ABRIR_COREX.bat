@echo off
cd /d "%~dp0corex_desktop"
if not exist ".venv\Scripts\pythonw.exe" (
 echo Execute primeiro o arquivo INSTALAR_COREX.bat
 pause
 exit /b 1
)
start "" /b ".venv\Scripts\pythonw.exe" "main.py"
exit /b 0
