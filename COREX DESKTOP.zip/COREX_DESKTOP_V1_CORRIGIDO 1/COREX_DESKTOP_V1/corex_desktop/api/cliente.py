import json
from pathlib import Path
from typing import Any

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_CONFIG = Path(__file__).resolve().parent.parent / "config.json"


class ErroAPI(RuntimeError):
    pass


class ClienteAPI:
    def __init__(self):
        self.token = None
        self.usuario = None
        self.carregar_configuracao()

    def carregar_configuracao(self):
        padrao = {
            "api_url": "https://corextech.pythonanywhere.com",
            "timeout": 20
        }

        try:
            dados = json.loads(_CONFIG.read_text(encoding="utf-8"))
        except Exception:
            dados = padrao

            try:
                _CONFIG.write_text(
                    json.dumps(padrao, indent=2),
                    encoding="utf-8"
                )
            except Exception:
                pass

        self.api_url = str(
            dados.get("api_url") or padrao["api_url"]
        ).rstrip("/")

        self.timeout = int(
            dados.get("timeout") or padrao["timeout"]
        )

    def _request(
        self,
        metodo: str,
        caminho: str,
        *,
        dados=None,
        params=None,
        autenticado=True
    ) -> dict[str, Any]:

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        if autenticado:
            if not self.token:
                raise ErroAPI(
                    "Sua sessão não está ativa. Entre novamente."
                )

            headers["Authorization"] = f"Bearer {self.token}"

        try:
            resposta = requests.request(
                method=metodo,
                url=self.api_url + caminho,
                json=dados,
                params=params,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )

        except requests.Timeout as erro:
            raise ErroAPI(
                "O servidor COREX demorou muito para responder."
            ) from erro

        except requests.ConnectionError as erro:
            raise ErroAPI(
                "Não foi possível conectar ao servidor COREX.\n"
                "Verifique a conexão com a internet e tente novamente."
            ) from erro

        except requests.RequestException as erro:
            raise ErroAPI(
                f"Não foi possível conectar ao servidor COREX.\n{erro}"
            ) from erro

        try:
            conteudo = resposta.json()

        except ValueError as erro:
            detalhe = (
                f"{metodo} {caminho} — "
                f"HTTP {resposta.status_code}"
            )

            if resposta.status_code == 404:
                detalhe += (
                    "\nA rota não existe no servidor. "
                    "Verifique o api_desktop.py no PythonAnywhere."
                )

            elif resposta.status_code == 405:
                detalhe += (
                    "\nA rota existe, mas não aceita este método."
                )

            elif resposta.status_code >= 500:
                detalhe += (
                    "\nOcorreu um erro interno no servidor."
                )

            raise ErroAPI(
                f"O servidor retornou uma resposta inválida.\n{detalhe}"
            ) from erro

        if not resposta.ok or not conteudo.get("ok", False):
            mensagem = (
                conteudo.get("erro")
                or f"Erro HTTP {resposta.status_code}."
            )

            if resposta.status_code == 404:
                mensagem += (
                    f"\nRota ausente: {metodo} {caminho}."
                )

            elif resposta.status_code == 405:
                mensagem += (
                    f"\nMétodo recusado: {metodo} {caminho}."
                )

            elif resposta.status_code == 401:
                self.token = None
                self.usuario = None

            raise ErroAPI(mensagem)

        return conteudo

    def login(self, email, senha):
        resposta = self._request(
            "POST",
            "/api/desktop/login",
            dados={
                "email": email,
                "senha": senha
            },
            autenticado=False
        )

        self.token = resposta["token"]
        self.usuario = resposta["usuario"]

        return self.usuario

    def logout(self):
        self.token = None
        self.usuario = None

    def listar_chamados(self):
        return self._request(
            "GET",
            "/api/desktop/chamados"
        )["chamados"]

    def buscar_chamado(self, id_):
        return self._request(
            "GET",
            f"/api/desktop/chamados/{id_}"
        )["chamado"]

    def abrir_chamado(self, dados):
        return self._request(
            "POST",
            "/api/desktop/chamados",
            dados=dados
        )["chamado"]

    def atualizar_chamado(self, id_, dados):
        return self._request(
            "PUT",
            f"/api/desktop/chamados/{id_}",
            dados=dados
        )["chamado"]

    def comentarios(self, id_):
        return self._request(
            "GET",
            f"/api/desktop/chamados/{id_}/comentarios"
        )["comentarios"]

    def comentar(self, id_, texto):
        return self._request(
            "POST",
            f"/api/desktop/chamados/{id_}/comentarios",
            dados={"texto": texto}
        )

    def tecnicos(self, setor=""):
        params = {"setor": setor} if setor else None

        return self._request(
            "GET",
            "/api/desktop/tecnicos",
            params=params
        )["usuarios"]

    def listar_notificacoes(self):
        return self._request(
            "GET",
            "/api/desktop/notificacoes"
        )["notificacoes"]

    def marcar_notificacao(self, id_):
        return self._request(
            "PUT",
            f"/api/desktop/notificacoes/{id_}/lida"
        )

    def marcar_todas(self):
        return self._request(
            "PUT",
            "/api/desktop/notificacoes/marcar-todas"
        )

    def contador(self):
        resposta = self._request(
            "GET",
            "/api/desktop/notificacoes/contador"
        )

        return int(resposta["quantidade"])

    def listar_usuarios(self, busca=""):
        params = {"busca": busca} if busca else None

        return self._request(
            "GET",
            "/api/desktop/usuarios",
            params=params
        )["usuarios"]

    def criar_usuario(self, dados):
        return self._request(
            "POST",
            "/api/desktop/usuarios",
            dados=dados
        )["usuario"]

    def atualizar_usuario(self, id_, dados):
        return self._request(
            "PUT",
            f"/api/desktop/usuarios/{id_}",
            dados=dados
        )["usuario"]

    def excluir_usuario(self, id_):
        return self._request(
            "DELETE",
            f"/api/desktop/usuarios/{id_}"
        )