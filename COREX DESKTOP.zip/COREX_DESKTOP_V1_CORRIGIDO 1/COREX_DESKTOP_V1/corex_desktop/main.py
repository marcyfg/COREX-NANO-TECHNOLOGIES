import sys
from PySide6.QtWidgets import QApplication
from api.cliente import ClienteAPI
from telas.login import TelaLogin
from telas.principal import JanelaPrincipal
from tema import TEMA

class Aplicacao:
    def __init__(self):
        self.api=ClienteAPI(); self.login=None; self.principal=None; self.mostrar_login()
    def mostrar_login(self):
        self.login=TelaLogin(self.api); self.login.autenticado.connect(self.mostrar_principal); self.login.show()
    def mostrar_principal(self,usuario):
        self.principal=JanelaPrincipal(self.api,self.mostrar_login); self.principal.show(); self.login.close()

if __name__=='__main__':
    app=QApplication(sys.argv); app.setStyleSheet(TEMA); controlador=Aplicacao(); sys.exit(app.exec())
