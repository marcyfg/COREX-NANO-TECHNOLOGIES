from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QFrame,QLabel,QLineEdit,QPushButton,QMessageBox
from PySide6.QtCore import Signal,Qt
from api.cliente import ErroAPI

class TelaLogin(QWidget):
    autenticado=Signal(dict)
    def __init__(self,api):
        super().__init__(); self.api=api
        self.setWindowTitle("COREX Desktop - Login"); self.resize(900,560)
        raiz=QHBoxLayout(self); raiz.setContentsMargins(0,0,0,0)
        lateral=QFrame(); lateral.setStyleSheet("background:#152238;"); lv=QVBoxLayout(lateral)
        marca=QLabel("COREX"); marca.setStyleSheet("color:white;font-size:42px;font-weight:700")
        frase=QLabel("Soluções em Tecnologia\nCentral de atendimento desktop")
        frase.setStyleSheet("color:#cbd5e1;font-size:18px"); lv.addStretch(); lv.addWidget(marca); lv.addWidget(frase); lv.addStretch()
        painel=QFrame(); v=QVBoxLayout(painel); v.setContentsMargins(85,70,85,70)
        t=QLabel("Entrar no sistema"); t.setObjectName("titulo"); s=QLabel("Utilize o mesmo usuário do portal COREX."); s.setObjectName("subtitulo")
        self.email=QLineEdit(); self.email.setPlaceholderText("E-mail")
        self.senha=QLineEdit(); self.senha.setPlaceholderText("Senha"); self.senha.setEchoMode(QLineEdit.Password)
        botao=QPushButton("Entrar"); botao.clicked.connect(self.entrar); self.senha.returnPressed.connect(self.entrar)
        v.addWidget(t); v.addWidget(s); v.addSpacing(25); v.addWidget(QLabel("E-mail")); v.addWidget(self.email); v.addWidget(QLabel("Senha")); v.addWidget(self.senha); v.addWidget(botao); v.addStretch()
        raiz.addWidget(lateral,5); raiz.addWidget(painel,5)
    def entrar(self):
        try:
            u=self.api.login(self.email.text().strip(),self.senha.text())
            self.autenticado.emit(u)
        except ErroAPI as e: QMessageBox.warning(self,"Não foi possível entrar",str(e))
