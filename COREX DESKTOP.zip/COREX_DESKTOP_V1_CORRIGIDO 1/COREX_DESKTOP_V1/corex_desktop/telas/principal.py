from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QTimer
from api.cliente import ErroAPI

SETORES=["Service Desk / Triagem","Administração","Suporte Técnico","Laboratório de Informática","Servidores e Redes","Segurança da Informação","Desenvolvimento - Devs"]
CATEGORIAS=["Hardware","Software","Rede/Internet","E-mail","Impressora","Servidor","Usuário","Windows"]
PRIORIDADES=["Baixa","Média","Alta","Crítica"]
STATUS=[("aberto","Aberto / Fila Geral"),("em_andamento","Em andamento"),("aguardando_cliente","Aguardando cliente"),("aguardando_reclassificacao","Aguardando reclassificação"),("concluido","Concluído"),("encerrado_adm","Encerrado por administrador")]
CARGOS=[("CLIENTE","Cliente"),("TECNICO_COREX","Técnico CoreX"),("LIDER","Líder"),("SERVICE_DESK","Service Desk"),("ADMIN_SUPERVISOR","Administrador Supervisor")]

def alerta(pai,titulo,erro): QMessageBox.warning(pai,titulo,str(erro))

class PaginaDashboard(QWidget):
    def __init__(self,api):
        super().__init__(); self.api=api; v=QVBoxLayout(self)
        t=QLabel("Dashboard"); t.setObjectName("titulo"); self.boas=QLabel(); self.boas.setObjectName("subtitulo"); v.addWidget(t); v.addWidget(self.boas)
        h=QHBoxLayout(); self.cards=[]
        for nome in ["Total de chamados","Chamados abertos","Em andamento","Concluídos"]:
            f=QFrame(); f.setObjectName("card"); q=QVBoxLayout(f); q.addWidget(QLabel(nome)); n=QLabel("0"); n.setObjectName("numero"); q.addWidget(n); h.addWidget(f); self.cards.append(n)
        v.addLayout(h); info=QGroupBox("Informações"); iv=QVBoxLayout(info); iv.addWidget(QLabel("Sistema COREX Desktop integrado à base da VER42.")); iv.addWidget(QLabel("Os indicadores são atualizados a partir do servidor online.")); v.addWidget(info); v.addStretch()
    def atualizar(self):
        try:
            dados=self.api.listar_chamados(); self.boas.setText(f"Bem-vindo, {self.api.usuario['nome']} — {self.api.usuario['cargo']}")
            vals=[len(dados),sum(x['status']=='aberto' for x in dados),sum(x['status']=='em_andamento' for x in dados),sum(x['status'] in ('concluido','encerrado_adm') for x in dados)]
            for l,n in zip(self.cards,vals): l.setText(str(n))
        except ErroAPI as e: alerta(self,"Dashboard",e)

class PaginaNovoChamado(QWidget):
    def __init__(self,api,on_salvo):
        super().__init__(); self.api=api; self.on_salvo=on_salvo; f=QFormLayout(self)
        t=QLabel("Novo chamado"); t.setObjectName("titulo"); f.addRow(t)
        self.titulo=QLineEdit(); self.descricao=QTextEdit(); self.categoria=QComboBox(); self.categoria.addItems(CATEGORIAS)
        self.prioridade=QComboBox(); self.prioridade.addItems(PRIORIDADES); self.setor=QComboBox(); self.setor.addItems(SETORES); self.local=QLineEdit()
        f.addRow("Título:",self.titulo); f.addRow("Descrição:",self.descricao); f.addRow("Categoria:",self.categoria); f.addRow("Prioridade:",self.prioridade); f.addRow("Setor responsável:",self.setor); f.addRow("Local do problema:",self.local)
        b=QPushButton("Abrir chamado"); b.clicked.connect(self.salvar); f.addRow(b)
    def preparar(self):
        cliente=self.api.usuario.get('cargo')=='CLIENTE'; self.prioridade.setEnabled(not cliente); self.setor.setEnabled(not cliente)
    def salvar(self):
        d={"titulo":self.titulo.text(),"descricao":self.descricao.toPlainText(),"categoria":self.categoria.currentText(),"prioridade":self.prioridade.currentText(),"setor":self.setor.currentText(),"local":self.local.text()}
        try:
            c=self.api.abrir_chamado(d); QMessageBox.information(self,"COREX",f"Chamado {c.get('numero_ticket') or c['id']} aberto com sucesso.")
            self.titulo.clear(); self.descricao.clear(); self.local.clear(); self.on_salvo()
        except ErroAPI as e: alerta(self,"Não foi possível abrir",e)

class PaginaChamados(QWidget):
    def __init__(self,api):
        super().__init__(); self.api=api; v=QVBoxLayout(self); h=QHBoxLayout(); t=QLabel("Chamados"); t.setObjectName("titulo"); self.busca=QLineEdit(); self.busca.setPlaceholderText("Pesquisar por ticket, título, solicitante ou setor"); self.busca.textChanged.connect(self.filtrar); b=QPushButton("Atualizar"); b.clicked.connect(self.atualizar); h.addWidget(t); h.addStretch(); h.addWidget(self.busca); h.addWidget(b); v.addLayout(h)
        self.tab=QTableWidget(0,7); self.tab.setHorizontalHeaderLabels(["ID/Ticket","Título","Solicitante","Prioridade","Status","Setor","Responsável"]); self.tab.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); self.tab.setSelectionBehavior(QTableWidget.SelectRows); self.tab.setEditTriggers(QTableWidget.NoEditTriggers); self.tab.doubleClicked.connect(self.detalhar); v.addWidget(self.tab); self.dados=[]
    def atualizar(self):
        try: self.dados=self.api.listar_chamados(); self.preencher(self.dados)
        except ErroAPI as e: alerta(self,"Chamados",e)
    def preencher(self,dados):
        self.tab.setRowCount(0)
        for c in dados:
            r=self.tab.rowCount(); self.tab.insertRow(r); vals=[c.get('numero_ticket') or c['id'],c['titulo'],c.get('solicitante',''),c.get('prioridade',''),c.get('status',''),c.get('setor_responsavel',''),c.get('responsavel') or 'Não atribuído']
            for j,x in enumerate(vals): self.tab.setItem(r,j,QTableWidgetItem(str(x)))
            self.tab.item(r,0).setData(Qt.UserRole,c['id'])
    def filtrar(self):
        q=self.busca.text().lower().strip(); self.preencher([c for c in self.dados if q in ' '.join(str(v).lower() for v in c.values())])
    def detalhar(self):
        r=self.tab.currentRow()
        if r>=0: DialogoChamado(self.api,self.tab.item(r,0).data(Qt.UserRole),self).exec(); self.atualizar()

class DialogoChamado(QDialog):
    def __init__(self,api,id_,pai=None):
        super().__init__(pai); self.api=api; self.id=id_; self.setWindowTitle("Detalhes do chamado"); self.resize(760,650); self.v=QVBoxLayout(self)
        self.info=QLabel(); self.info.setWordWrap(True); self.v.addWidget(self.info)
        form=QFormLayout(); self.status=QComboBox(); [self.status.addItem(n,c) for c,n in STATUS]; self.prio=QComboBox(); self.prio.addItems(PRIORIDADES); self.setor=QComboBox(); self.setor.addItems(SETORES); self.resp=QComboBox(); form.addRow("Status:",self.status); form.addRow("Prioridade:",self.prio); form.addRow("Setor:",self.setor); form.addRow("Responsável:",self.resp); self.v.addLayout(form)
        salvar=QPushButton("Salvar tratamento"); salvar.clicked.connect(self.salvar); self.v.addWidget(salvar)
        self.lista=QListWidget(); self.v.addWidget(QLabel("Comentários")); self.v.addWidget(self.lista); h=QHBoxLayout(); self.com=QLineEdit(); self.com.setPlaceholderText("Adicionar comentário obrigatório sobre a ação..."); bc=QPushButton("Comentar"); bc.clicked.connect(self.comentar); h.addWidget(self.com); h.addWidget(bc); self.v.addLayout(h); self.carregar()
    def carregar(self):
        try:
            c=self.api.buscar_chamado(self.id); self.c=c; self.info.setText(f"<b>{c.get('numero_ticket') or c['id']} — {c['titulo']}</b><br>{c['descricao']}<br><br>Solicitante: {c.get('solicitante')} | Local: {c.get('local_problema') or '-'}")
            self.status.setCurrentIndex(max(0,self.status.findData(c['status']))); self.prio.setCurrentText(c['prioridade']); self.setor.setCurrentText(c['setor_responsavel'])
            self.resp.clear(); self.resp.addItem("Não atribuído",None)
            for u in self.api.tecnicos(self.setor.currentText()): self.resp.addItem(f"{u['nome']} — {u['cargo']}",u['id'])
            idx=self.resp.findData(c.get('id_responsavel')); self.resp.setCurrentIndex(idx if idx>=0 else 0)
            self.lista.clear()
            for x in self.api.comentarios(self.id): self.lista.addItem(f"{x['usuario']} — {x.get('data_criacao','')[:16]}\n{x['texto']}")
            permitido=self.api.usuario.get('cargo')!='CLIENTE'; self.status.setEnabled(permitido); self.prio.setEnabled(permitido); self.setor.setEnabled(permitido); self.resp.setEnabled(permitido)
        except ErroAPI as e: alerta(self,"Chamado",e)
    def salvar(self):
        if not self.com.text().strip(): QMessageBox.warning(self,"Comentário obrigatório","Descreva no campo de comentário o que foi alterado."); return
        try:
            self.api.atualizar_chamado(self.id,{"status":self.status.currentData(),"prioridade":self.prio.currentText(),"setor":self.setor.currentText(),"id_responsavel":self.resp.currentData()}); self.api.comentar(self.id,self.com.text()); self.com.clear(); self.carregar(); QMessageBox.information(self,"COREX","Chamado atualizado.")
        except ErroAPI as e: alerta(self,"Atualização",e)
    def comentar(self):
        try: self.api.comentar(self.id,self.com.text()); self.com.clear(); self.carregar()
        except ErroAPI as e: alerta(self,"Comentário",e)

class PaginaNotificacoes(QWidget):
    def __init__(self,api):
        super().__init__(); self.api=api; v=QVBoxLayout(self); h=QHBoxLayout(); t=QLabel("Notificações"); t.setObjectName("titulo"); b=QPushButton("Marcar todas como lidas"); b.clicked.connect(self.todas); h.addWidget(t); h.addStretch(); h.addWidget(b); v.addLayout(h); self.lista=QListWidget(); self.lista.itemDoubleClicked.connect(self.abrir); v.addWidget(self.lista); self.dados=[]
    def atualizar(self):
        try:
            self.dados=self.api.listar_notificacoes(); self.lista.clear()
            for n in self.dados: item=QListWidgetItem(("● " if not n['lida'] else "")+f"{n['titulo']}\n{n['mensagem']}"); item.setData(Qt.UserRole,n); self.lista.addItem(item)
        except ErroAPI as e: alerta(self,"Notificações",e)
    def abrir(self,item):
        n=item.data(Qt.UserRole)
        try: self.api.marcar_notificacao(n['id'])
        except ErroAPI: pass
        if n.get('id_tarefa'): DialogoChamado(self.api,n['id_tarefa'],self).exec()
        self.atualizar()
    def todas(self):
        try: self.api.marcar_todas(); self.atualizar()
        except ErroAPI as e: alerta(self,"Notificações",e)

class PaginaUsuarios(QWidget):
    def __init__(self,api):
        super().__init__(); self.api=api; raiz=QHBoxLayout(self); esq=QVBoxLayout(); h=QHBoxLayout(); t=QLabel("Gerenciar usuários"); t.setObjectName("titulo"); self.busca=QLineEdit(); self.busca.setPlaceholderText("Buscar nome ou e-mail"); self.busca.returnPressed.connect(self.atualizar); bb=QPushButton("Buscar"); bb.clicked.connect(self.atualizar); h.addWidget(t); h.addWidget(self.busca); h.addWidget(bb); esq.addLayout(h); self.tab=QTableWidget(0,5); self.tab.setHorizontalHeaderLabels(["ID","Nome","E-mail","Cargo","Setor"]); self.tab.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); self.tab.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch); self.tab.setSelectionBehavior(QTableWidget.SelectRows); self.tab.itemSelectionChanged.connect(self.selecionar); esq.addWidget(self.tab); raiz.addLayout(esq,3)
        box=QGroupBox("Dados do usuário"); f=QFormLayout(box); self.id=None; self.nome=QLineEdit(); self.email=QLineEdit(); self.senha=QLineEdit(); self.senha.setEchoMode(QLineEdit.Password); self.cargo=QComboBox(); [self.cargo.addItem(n,c) for c,n in CARGOS]; self.setor=QComboBox(); self.setor.addItems(SETORES); self.empresa=QLineEdit(); f.addRow("Nome:",self.nome); f.addRow("E-mail:",self.email); f.addRow("Nova senha:",self.senha); f.addRow("Cargo:",self.cargo); f.addRow("Setor:",self.setor); f.addRow("Empresa:",self.empresa); novo=QPushButton("Novo"); novo.setObjectName("secundario"); novo.clicked.connect(self.limpar); salvar=QPushButton("Salvar"); salvar.clicked.connect(self.salvar); excluir=QPushButton("Excluir / desativar"); excluir.setObjectName("perigo"); excluir.clicked.connect(self.excluir); f.addRow(novo,salvar); f.addRow(excluir); raiz.addWidget(box,2)
    def atualizar(self):
        try:
            dados=self.api.listar_usuarios(self.busca.text()); self.tab.setRowCount(0)
            for u in dados:
                r=self.tab.rowCount(); self.tab.insertRow(r)
                for j,x in enumerate([u['id'],u['nome'],u['email'],u['cargo'],u['setor']]): self.tab.setItem(r,j,QTableWidgetItem(str(x)))
                self.tab.item(r,0).setData(Qt.UserRole,u)
        except ErroAPI as e: alerta(self,"Usuários",e)
    def selecionar(self):
        r=self.tab.currentRow()
        if r<0:return
        u=self.tab.item(r,0).data(Qt.UserRole); self.id=u['id']; self.nome.setText(u['nome']); self.email.setText(u['email']); self.cargo.setCurrentIndex(max(0,self.cargo.findData(u['cargo']))); self.setor.setCurrentText(u['setor']); self.empresa.setText(u.get('empresa','')); self.senha.clear()
    def limpar(self): self.id=None; self.nome.clear(); self.email.clear(); self.senha.clear(); self.empresa.clear(); self.cargo.setCurrentIndex(0); self.setor.setCurrentIndex(0); self.tab.clearSelection()
    def salvar(self):
        d={"nome":self.nome.text(),"email":self.email.text(),"senha":self.senha.text(),"cargo":self.cargo.currentData(),"setor":self.setor.currentText(),"empresa":self.empresa.text()}
        try:
            if self.id:self.api.atualizar_usuario(self.id,d)
            else:self.api.criar_usuario(d)
            QMessageBox.information(self,"COREX","Usuário salvo com sucesso."); self.limpar(); self.atualizar()
        except ErroAPI as e: alerta(self,"Usuário",e)
    def excluir(self):
        if not self.id:return
        if QMessageBox.question(self,"Confirmação","Excluir este usuário? Se houver histórico, ele será desativado.")!=QMessageBox.Yes:return
        try:self.api.excluir_usuario(self.id); self.limpar(); self.atualizar()
        except ErroAPI as e: alerta(self,"Exclusão",e)

class JanelaPrincipal(QMainWindow):
    def __init__(self,api,on_logout):
        super().__init__(); self.api=api; self.on_logout=on_logout; self.setWindowTitle("COREX Desktop V1"); self.resize(1280,760)
        central=QWidget(); self.setCentralWidget(central); h=QHBoxLayout(central); h.setContentsMargins(0,0,0,0)
        menu=QFrame(); menu.setObjectName("menu"); menu.setFixedWidth(230); mv=QVBoxLayout(menu); marca=QLabel("COREX"); marca.setObjectName("marca"); mv.addWidget(marca); self.botoes=[]
        self.stack=QStackedWidget(); self.dashboard=PaginaDashboard(api); self.novo=PaginaNovoChamado(api,self.recarregar); self.chamados=PaginaChamados(api); self.notif=PaginaNotificacoes(api); self.usuarios=PaginaUsuarios(api)
        paginas=[("Dashboard",self.dashboard),("Novo chamado",self.novo),("Chamados",self.chamados),("Notificações",self.notif)]
        if api.usuario.get('cargo') in ('ADMIN_SUPERVISOR','LIDER'): paginas.append(("Usuários",self.usuarios))
        for nome,p in paginas:
            self.stack.addWidget(p); b=QPushButton(nome); b.setObjectName("menuBtn"); b.setCheckable(True); b.clicked.connect(lambda _,pg=p,bt=b:self.mostrar(pg,bt)); mv.addWidget(b); self.botoes.append(b)
        mv.addStretch(); sair=QPushButton("Sair"); sair.setObjectName("menuBtn"); sair.clicked.connect(self.sair); mv.addWidget(sair); h.addWidget(menu); h.addWidget(self.stack,1)
        self.timer=QTimer(self); self.timer.timeout.connect(self.atualizar_contador); self.timer.start(30000); self.mostrar(self.dashboard,self.botoes[0]); self.novo.preparar()
    def mostrar(self,p,b):
        self.stack.setCurrentWidget(p)
        for x in self.botoes:x.setChecked(x is b)
        if hasattr(p,'atualizar'):p.atualizar()
    def recarregar(self): self.chamados.atualizar(); self.dashboard.atualizar()
    def atualizar_contador(self):
        try:
            n=self.api.contador()
            for b in self.botoes:
                if b.text().startswith('Notificações'):b.setText(f"Notificações ({n})" if n else "Notificações")
        except Exception:pass
    def sair(self): self.api.logout(); self.close(); self.on_logout()
