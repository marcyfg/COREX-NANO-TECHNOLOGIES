TEMA = """
QWidget { background:#f3f5f8; color:#182230; font:14px 'Segoe UI'; }
QFrame#menu { background:#152238; border:none; }
QLabel#marca { color:white; font-size:24px; font-weight:700; padding:16px; }
QPushButton#menuBtn { color:#dfe7f3; background:transparent; border:none; text-align:left; padding:13px 18px; border-radius:7px; }
QPushButton#menuBtn:hover { background:#243754; }
QPushButton#menuBtn:checked { background:#2f69bf; color:white; font-weight:600; }
QPushButton { background:#2f69bf; color:white; border:none; padding:9px 15px; border-radius:6px; }
QPushButton:hover { background:#255aa8; }
QPushButton#secundario { background:#e5eaf1; color:#243247; }
QPushButton#perigo { background:#b93131; }
QLineEdit,QTextEdit,QComboBox,QTableWidget { background:white; border:1px solid #cfd7e3; border-radius:6px; padding:7px; }
QTableWidget { gridline-color:#e3e7ed; }
QHeaderView::section { background:#e9edf3; padding:8px; border:none; font-weight:600; }
QGroupBox { background:white; border:1px solid #dce2ea; border-radius:9px; margin-top:12px; padding:14px; font-weight:600; }
QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; }
QLabel#titulo { font-size:25px; font-weight:700; color:#17243a; }
QLabel#subtitulo { color:#64748b; }
QFrame#card { background:white; border:1px solid #dce2ea; border-radius:10px; }
QLabel#numero { font-size:28px; font-weight:700; color:#2f69bf; }
"""
