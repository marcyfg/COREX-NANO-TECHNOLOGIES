"""API JSON usada pelo aplicativo COREX Desktop.

O desktop não acessa o arquivo SQLite diretamente. Todas as operações passam
por esta API, portanto Web e Desktop utilizam o mesmo banco no PythonAnywhere.
"""
from functools import wraps
from datetime import datetime

from flask import request, jsonify, g
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from gerenciador import app, database, bcrypt
from gerenciador.models import (
    Usuario, Tarefa, Comentario, Notificacao,
    SETORES_PADRAO, CATEGORIAS_CHAMADO, PRIORIDADES_CHAMADO, STATUS_CHAMADO,
)

TOKEN_MAX_AGE = 60 * 60 * 12
serializer = URLSafeTimedSerializer(app.config["SECRET_KEY"], salt="corex-desktop-api")


def resposta_erro(mensagem, status=400):
    return jsonify({"ok": False, "erro": mensagem}), status


def usuario_json(usuario):
    return {
        "id": usuario.id,
        "nome": usuario.username,
        "username": usuario.username,
        "email": usuario.email,
        "cargo": usuario.cargo or "CLIENTE",
        "setor": usuario.setor or "Suporte Técnico",
        "empresa": usuario.empresa or "",
        "ativo": bool(usuario.ativo),
    }


def chamado_json(tarefa):
    solicitante = Usuario.query.get(tarefa.id_solicitante) if tarefa.id_solicitante else None
    responsavel = Usuario.query.get(tarefa.id_usuario) if tarefa.id_usuario else None
    return {
        "id": tarefa.id,
        "numero_ticket": tarefa.numero_ticket,
        "titulo": tarefa.titulo,
        "descricao": tarefa.descricao or "",
        "categoria": tarefa.categoria,
        "prioridade": tarefa.prioridade,
        "status": tarefa.status,
        "setor_responsavel": tarefa.setor,
        "local_problema": tarefa.setor_cliente or "",
        "id_solicitante": tarefa.id_solicitante,
        "id_responsavel": tarefa.id_usuario,
        "solicitante": solicitante.username if solicitante else "Não informado",
        "responsavel": responsavel.username if responsavel else None,
        "data_criacao": tarefa.data_criacao.isoformat() if tarefa.data_criacao else None,
        "data_atualizacao": tarefa.data_atualizacao.isoformat() if tarefa.data_atualizacao else None,
    }


def api_login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        cabecalho = request.headers.get("Authorization", "")
        if not cabecalho.startswith("Bearer "):
            return resposta_erro("Autenticação necessária.", 401)
        token = cabecalho[7:].strip()
        try:
            dados = serializer.loads(token, max_age=TOKEN_MAX_AGE)
        except SignatureExpired:
            return resposta_erro("Sessão expirada. Entre novamente.", 401)
        except BadSignature:
            return resposta_erro("Sessão inválida.", 401)
        usuario = Usuario.query.get(dados.get("usuario_id"))
        if not usuario or not usuario.ativo:
            return resposta_erro("Usuário inexistente ou inativo.", 401)
        g.usuario_api = usuario
        return func(*args, **kwargs)
    return wrapper


def pode_ver_chamado(usuario, tarefa):
    cargo = usuario.cargo or "CLIENTE"
    if cargo == "CLIENTE":
        return tarefa.id_solicitante == usuario.id
    if cargo in ("TECNICO_COREX", "LIDER"):
        return tarefa.setor == usuario.setor or tarefa.id_usuario == usuario.id
    return cargo in ("SERVICE_DESK", "ADMIN_SUPERVISOR")


@app.get("/api/desktop/status")
def api_desktop_status():
    return jsonify({"ok": True, "servico": "COREX Desktop API", "versao": "V1.1", "rotas_completas": True})


@app.post("/api/desktop/login")
def api_desktop_login():
    dados = request.get_json(silent=True) or {}
    email = (dados.get("email") or "").strip().lower()
    senha = dados.get("senha") or ""
    usuario = Usuario.query.filter_by(email=email).first()
    if not usuario or not usuario.ativo or not bcrypt.check_password_hash(usuario.senha, senha):
        return resposta_erro("E-mail, senha ou usuário inativo.", 401)
    token = serializer.dumps({"usuario_id": usuario.id})
    return jsonify({"ok": True, "token": token, "usuario": usuario_json(usuario)})


@app.get("/api/desktop/usuarios/quantidade")
def api_desktop_quantidade_usuarios():
    return jsonify({"ok": True, "quantidade": Usuario.query.count()})


@app.post("/api/desktop/usuarios")
def api_desktop_criar_usuario():
    dados = request.get_json(silent=True) or {}
    auth = request.headers.get("Authorization", "")
    usuario_logado = None
    if auth.startswith("Bearer "):
        try:
            token_dados = serializer.loads(auth[7:].strip(), max_age=TOKEN_MAX_AGE)
            usuario_logado = Usuario.query.get(token_dados.get("usuario_id"))
        except Exception:
            usuario_logado = None

    cargo = (dados.get("cargo") or "CLIENTE").strip()
    if usuario_logado is None:
        cargo = "CLIENTE"
    elif usuario_logado.cargo not in ("ADMIN_SUPERVISOR", "LIDER"):
        return resposta_erro("Seu perfil não pode cadastrar usuários.", 403)
    elif usuario_logado.cargo == "LIDER" and cargo not in ("TECNICO_COREX", "CLIENTE"):
        return resposta_erro("Líder pode cadastrar somente Técnico ou Cliente.", 403)

    nome = (dados.get("nome") or "").strip()
    email = (dados.get("email") or "").strip().lower()
    senha = dados.get("senha") or ""
    setor = (dados.get("setor") or "Suporte Técnico").strip()
    empresa = (dados.get("empresa") or "").strip()
    if not nome or not email or len(senha) < 8:
        return resposta_erro("Informe nome, e-mail e senha com pelo menos 8 caracteres.")
    if Usuario.query.filter_by(email=email).first():
        return resposta_erro("E-mail já cadastrado.", 409)
    if setor not in SETORES_PADRAO:
        setor = "Suporte Técnico"

    usuario = Usuario(
        username=nome,
        email=email,
        senha=bcrypt.generate_password_hash(senha).decode("utf-8"),
        cargo=cargo,
        setor=setor,
        empresa=empresa or None,
        ativo=True,
        admin=cargo == "ADMIN_SUPERVISOR",
    )
    database.session.add(usuario)
    database.session.commit()
    return jsonify({"ok": True, "usuario": usuario_json(usuario)}), 201


@app.get("/api/desktop/tecnicos")
@api_login_required
def api_desktop_tecnicos():
    setor = (request.args.get("setor") or "").strip()
    consulta = Usuario.query.filter(
        Usuario.ativo.is_(True),
        Usuario.cargo.in_(("TECNICO_COREX", "LIDER", "SERVICE_DESK", "ADMIN_SUPERVISOR")),
    )
    if setor:
        consulta = consulta.filter_by(setor=setor)
    return jsonify({"ok": True, "usuarios": [usuario_json(u) for u in consulta.order_by(Usuario.username).all()]})


@app.get("/api/desktop/chamados")
@api_login_required
def api_desktop_listar_chamados():
    usuario = g.usuario_api
    consulta = Tarefa.query
    if usuario.cargo == "CLIENTE":
        consulta = consulta.filter_by(id_solicitante=usuario.id)
    elif usuario.cargo in ("TECNICO_COREX", "LIDER"):
        consulta = consulta.filter((Tarefa.setor == usuario.setor) | (Tarefa.id_usuario == usuario.id))
    tarefas = consulta.order_by(Tarefa.id.desc()).all()
    return jsonify({"ok": True, "chamados": [chamado_json(t) for t in tarefas]})


@app.post("/api/desktop/chamados")
@api_login_required
def api_desktop_abrir_chamado():
    usuario = g.usuario_api
    dados = request.get_json(silent=True) or {}
    titulo = (dados.get("titulo") or "").strip()
    descricao = (dados.get("descricao") or "").strip()
    categoria = dados.get("categoria") or "Hardware"
    prioridade = dados.get("prioridade") or "Média"
    setor = dados.get("setor") or "Service Desk / Triagem"
    local = (dados.get("local") or "").strip()
    if len(titulo) < 6 or len(descricao) < 15:
        return resposta_erro("Título mínimo: 6 caracteres. Descrição mínima: 15.")
    if categoria not in dict(CATEGORIAS_CHAMADO):
        categoria = "Hardware"
    if prioridade not in dict(PRIORIDADES_CHAMADO):
        prioridade = "Média"
    if usuario.cargo == "CLIENTE":
        prioridade = "Média"
        setor = "Service Desk / Triagem"
    elif setor not in SETORES_PADRAO:
        setor = "Service Desk / Triagem"

    tarefa = Tarefa(
        titulo=titulo, descricao=descricao, categoria=categoria,
        prioridade=prioridade, status="aberto", setor=setor,
        setor_cliente=local or None, id_solicitante=usuario.id,
    )
    database.session.add(tarefa)
    database.session.flush()
    tarefa.numero_ticket = f"CX-{datetime.utcnow():%Y%m}-{tarefa.id:05d}"
    database.session.commit()

    destinatarios = Usuario.query.filter(
        Usuario.ativo.is_(True),
        Usuario.cargo.in_(("SERVICE_DESK", "ADMIN_SUPERVISOR")),
    ).all()
    for destinatario in destinatarios:
        database.session.add(Notificacao(
            titulo="Novo chamado na Fila Geral",
            mensagem=f"{tarefa.numero_ticket} - {tarefa.titulo}",
            id_usuario=destinatario.id,
            id_tarefa=tarefa.id,
        ))
    database.session.commit()
    return jsonify({"ok": True, "chamado": chamado_json(tarefa)}), 201


@app.get("/api/desktop/chamados/<int:chamado_id>")
@api_login_required
def api_desktop_buscar_chamado(chamado_id):
    tarefa = Tarefa.query.get_or_404(chamado_id)
    if not pode_ver_chamado(g.usuario_api, tarefa):
        return resposta_erro("Você não pode visualizar este chamado.", 403)
    return jsonify({"ok": True, "chamado": chamado_json(tarefa)})


@app.put("/api/desktop/chamados/<int:chamado_id>")
@api_login_required
def api_desktop_atualizar_chamado(chamado_id):
    usuario = g.usuario_api
    if usuario.cargo == "CLIENTE":
        return resposta_erro("Cliente não pode tratar chamados.", 403)
    tarefa = Tarefa.query.get_or_404(chamado_id)
    if not pode_ver_chamado(usuario, tarefa):
        return resposta_erro("Você não pode alterar este chamado.", 403)
    dados = request.get_json(silent=True) or {}
    status = dados.get("status") or tarefa.status
    prioridade = dados.get("prioridade") or tarefa.prioridade
    setor = dados.get("setor") or tarefa.setor
    id_responsavel = dados.get("id_responsavel")
    if status not in dict(STATUS_CHAMADO):
        return resposta_erro("Status inválido.")
    if prioridade not in dict(PRIORIDADES_CHAMADO):
        return resposta_erro("Prioridade inválida.")
    if setor not in SETORES_PADRAO:
        return resposta_erro("Setor inválido.")
    if id_responsavel is not None:
        responsavel = Usuario.query.get(id_responsavel)
        if not responsavel or not responsavel.ativo:
            return resposta_erro("Responsável inválido.")
    tarefa.status = status
    tarefa.prioridade = prioridade
    tarefa.setor = setor
    tarefa.id_usuario = id_responsavel
    tarefa.data_atualizacao = datetime.utcnow()
    database.session.commit()
    return jsonify({"ok": True, "chamado": chamado_json(tarefa)})


@app.get("/api/desktop/chamados/<int:chamado_id>/comentarios")
@api_login_required
def api_desktop_listar_comentarios(chamado_id):
    tarefa = Tarefa.query.get_or_404(chamado_id)
    if not pode_ver_chamado(g.usuario_api, tarefa):
        return resposta_erro("Você não pode visualizar este chamado.", 403)
    itens = []
    for comentario in Comentario.query.filter_by(id_tarefa=chamado_id).order_by(Comentario.id).all():
        itens.append({
            "id": comentario.id,
            "texto": comentario.texto,
            "usuario": comentario.usuario.username if comentario.usuario else "Usuário",
            "data_criacao": comentario.data_criacao.isoformat() if comentario.data_criacao else "",
        })
    return jsonify({"ok": True, "comentarios": itens})


@app.post("/api/desktop/chamados/<int:chamado_id>/comentarios")
@api_login_required
def api_desktop_adicionar_comentario(chamado_id):
    tarefa = Tarefa.query.get_or_404(chamado_id)
    if not pode_ver_chamado(g.usuario_api, tarefa):
        return resposta_erro("Você não pode comentar neste chamado.", 403)
    texto = ((request.get_json(silent=True) or {}).get("texto") or "").strip()
    if len(texto) < 2:
        return resposta_erro("Digite um comentário.")
    comentario = Comentario(texto=texto, id_tarefa=chamado_id, id_usuario=g.usuario_api.id)
    database.session.add(comentario)
    database.session.commit()
    return jsonify({"ok": True}), 201


@app.get("/api/desktop/notificacoes/contador")
@api_login_required
def api_desktop_contador_notificacoes():
    quantidade = Notificacao.query.filter_by(id_usuario=g.usuario_api.id, lida=False).count()
    return jsonify({"ok": True, "quantidade": quantidade})


# ===== Complementos do COREX Desktop V1 =====
def pode_gerenciar_usuarios(usuario):
    return (usuario.cargo or "CLIENTE") in ("ADMIN_SUPERVISOR", "LIDER")

@app.get("/api/desktop/usuarios")
@api_login_required
def api_desktop_listar_usuarios():
    if not pode_gerenciar_usuarios(g.usuario_api):
        return resposta_erro("Seu perfil não pode gerenciar usuários.", 403)
    busca = (request.args.get("busca") or "").strip()
    consulta = Usuario.query
    if g.usuario_api.cargo == "LIDER":
        consulta = consulta.filter_by(setor=g.usuario_api.setor)
    if busca:
        termo = f"%{busca}%"
        consulta = consulta.filter((Usuario.username.ilike(termo)) | (Usuario.email.ilike(termo)))
    return jsonify({"ok": True, "usuarios": [usuario_json(u) for u in consulta.order_by(Usuario.username).all()]})

@app.put("/api/desktop/usuarios/<int:usuario_id>")
@api_login_required
def api_desktop_atualizar_usuario(usuario_id):
    if not pode_gerenciar_usuarios(g.usuario_api):
        return resposta_erro("Seu perfil não pode alterar usuários.", 403)
    alvo = Usuario.query.get_or_404(usuario_id)
    if g.usuario_api.cargo == "LIDER" and alvo.setor != g.usuario_api.setor:
        return resposta_erro("Líder só pode alterar usuários do próprio setor.", 403)
    dados = request.get_json(silent=True) or {}
    nome = (dados.get("nome") or "").strip()
    email = (dados.get("email") or "").strip().lower()
    cargo = (dados.get("cargo") or alvo.cargo).strip()
    setor = (dados.get("setor") or alvo.setor).strip()
    senha = dados.get("senha") or ""
    if not nome or not email:
        return resposta_erro("Informe nome e e-mail.")
    existente = Usuario.query.filter(Usuario.email == email, Usuario.id != alvo.id).first()
    if existente:
        return resposta_erro("E-mail já cadastrado.", 409)
    if g.usuario_api.cargo == "LIDER" and cargo not in ("TECNICO_COREX", "CLIENTE"):
        return resposta_erro("Líder pode gerenciar somente Técnico ou Cliente.", 403)
    if setor not in SETORES_PADRAO:
        return resposta_erro("Setor inválido.")
    alvo.username = nome; alvo.email = email; alvo.cargo = cargo; alvo.setor = setor
    alvo.empresa = (dados.get("empresa") or "").strip() or None
    alvo.admin = cargo == "ADMIN_SUPERVISOR"
    if senha:
        if len(senha) < 8: return resposta_erro("A nova senha deve possuir pelo menos 8 caracteres.")
        alvo.senha = bcrypt.generate_password_hash(senha).decode("utf-8")
    database.session.commit()
    return jsonify({"ok": True, "usuario": usuario_json(alvo)})

@app.delete("/api/desktop/usuarios/<int:usuario_id>")
@api_login_required
def api_desktop_excluir_usuario(usuario_id):
    if not pode_gerenciar_usuarios(g.usuario_api):
        return resposta_erro("Seu perfil não pode excluir usuários.", 403)
    if usuario_id == g.usuario_api.id:
        return resposta_erro("Você não pode excluir o próprio usuário.")
    alvo = Usuario.query.get_or_404(usuario_id)
    if g.usuario_api.cargo == "LIDER" and alvo.setor != g.usuario_api.setor:
        return resposta_erro("Líder só pode excluir usuários do próprio setor.", 403)
    possui_historico = Tarefa.query.filter((Tarefa.id_solicitante == alvo.id) | (Tarefa.id_usuario == alvo.id)).first() is not None
    if possui_historico:
        alvo.ativo = False
        database.session.commit()
        return jsonify({"ok": True, "acao": "desativado", "mensagem": "Usuário desativado para preservar o histórico."})
    Notificacao.query.filter_by(id_usuario=alvo.id).delete()
    database.session.delete(alvo); database.session.commit()
    return jsonify({"ok": True, "acao": "excluido", "mensagem": "Usuário excluído."})

@app.get("/api/desktop/notificacoes")
@api_login_required
def api_desktop_listar_notificacoes():
    itens=[]
    consulta=Notificacao.query.filter_by(id_usuario=g.usuario_api.id).order_by(Notificacao.id.desc()).limit(100)
    for n in consulta.all():
        itens.append({"id":n.id,"titulo":n.titulo,"mensagem":n.mensagem,"lida":bool(n.lida),"id_tarefa":n.id_tarefa,"data_criacao":n.data_criacao.isoformat() if n.data_criacao else ""})
    return jsonify({"ok":True,"notificacoes":itens})

@app.route("/api/desktop/notificacoes/<int:notificacao_id>/lida", methods=["PUT", "POST", "PATCH"])
@api_login_required
def api_desktop_marcar_notificacao(notificacao_id):
    n=Notificacao.query.filter_by(id=notificacao_id,id_usuario=g.usuario_api.id).first_or_404(); n.lida=True; database.session.commit()
    return jsonify({"ok":True})

@app.route("/api/desktop/notificacoes/marcar-todas", methods=["PUT", "POST", "PATCH"])
@api_login_required
def api_desktop_marcar_todas():
    Notificacao.query.filter_by(id_usuario=g.usuario_api.id,lida=False).update({"lida":True}); database.session.commit()
    return jsonify({"ok":True})
