Option Explicit
Dim shell, fso, pasta, pythonw, comando
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName) & "\corex_desktop"
pythonw = pasta & "\.venv\Scripts\pythonw.exe"
If Not fso.FileExists(pythonw) Then
    MsgBox "Execute primeiro o arquivo INSTALAR_COREX.bat.", 48, "COREX Desktop"
    WScript.Quit 1
End If
comando = """" & pythonw & """ """ & pasta & "\main.py" & """"
shell.CurrentDirectory = pasta
shell.Run comando, 0, False
